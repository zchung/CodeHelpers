﻿namespace $safeprojectname$.Constants
{
    public class UrlConstants
    {
        public const string URL = "URL";
    }
}