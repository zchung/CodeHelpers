﻿namespace $safeprojectname$.Constants
{
    public class ApiNameConstants
    {
        public const string API_NAME = "ApiName";
    }
}