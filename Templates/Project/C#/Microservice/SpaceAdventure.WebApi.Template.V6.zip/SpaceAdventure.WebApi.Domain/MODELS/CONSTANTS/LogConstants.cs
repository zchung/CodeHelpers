﻿namespace $safeprojectname$.Models.Constants
{
    public class LogConstants
    {
        public static string Log = $"Log: {Constants.Prefix}_";
        public static string BasicLog = $" {Log}{nameof(BasicLog)}";
    }
}