﻿namespace $safeprojectname$.Models.Constants
{
    public class Constants
    {
        public const string Prefix = "Prefix";
    }
}