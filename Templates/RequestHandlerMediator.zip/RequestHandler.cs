﻿using Mediator;

namespace $rootnamespace$
{
    public class $safeitemname$ : IRequest<object>
    {

    }
    public class $safeitemname$Handler : IRequestHandler<$safeitemname$, object>
    {
        public ValueTask<object> Handle($safeitemname$ request, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}
